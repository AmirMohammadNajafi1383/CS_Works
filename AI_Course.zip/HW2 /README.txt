# Maze Localization Project

## 📌 Description
This project implements a logic-based agent that localizes itself in a known maze using perceptual inputs from wall sensors. The agent starts with no knowledge of its location and uses sensor-based inference to reduce its belief state.

## 📂 Files
- `main.py` : Main Python program (agent logic + visualization)
- `maze.txt` : Maze layout file (1 = wall, 0 = free space)
- `report.txt` : Project summary and explanation
- `README.md` : This file

## ▶️ How to Run
1. Make sure Python 3.8+ is installed.
2. Install required packages: pip install pygame
3. Run the program
## 🎮 Controls
- Use arrow keys to move the agent in the maze.
- The belief state is visualized in yellow on the left.
- On the right panel, each step shows your action and the resulting percept.

## ✅ Requirements
- Python 3.x
- Library: `pygame`

## 🔚 Termination
The simulation ends after:
- 10 steps, or
- When the agent localizes itself to a single possible cell.

