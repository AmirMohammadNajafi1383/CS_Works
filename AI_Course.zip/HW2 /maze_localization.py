import pygame
import sys
import random
from sympy import symbols, And, Not, satisfiable

# ===============================
#        Knowledge Base
# ===============================
class KnowledgeBase:
    def __init__(self):
        self.sentences = []
        self.time = 0

    def wall_symbol(self, r, c, direction):
        return symbols(f"W_{r}_{c}_{direction}")

    def percept_to_sentence(self, r, c, percept):
        dirs = ['N', 'S', 'E', 'W']
        clauses = []
        for i, val in enumerate(percept):
            sym = self.wall_symbol(r, c, dirs[i])
            if val:
                clauses.append(sym)
            else:
                clauses.append(Not(sym))
        return And(*clauses)

    def add_percept(self, r, c, percept):
        sentence = self.percept_to_sentence(r, c, percept)
        self.sentences.append(sentence)
        self.time += 1

    def entails(self, maze, start_pos, actions):
        rr, cc = start_pos
        assumptions = []

        for i, action in enumerate(actions):
            if action == 'UP': rr -= 1
            elif action == 'DOWN': rr += 1
            elif action == 'LEFT': cc -= 1
            elif action == 'RIGHT': cc += 1
            if rr < 0 or rr >= maze.rows or cc < 0 or cc >= maze.cols or maze.grid[rr][cc] == 1:
                return False
            percept = (
                1 if rr == 0 or maze.grid[rr-1][cc] == 1 else 0,
                1 if rr == maze.rows-1 or maze.grid[rr+1][cc] == 1 else 0,
                1 if cc == maze.cols-1 or maze.grid[rr][cc+1] == 1 else 0,
                1 if cc == 0 or maze.grid[rr][cc-1] == 1 else 0
            )
            assumptions.append(self.percept_to_sentence(rr, cc, percept))

        test = And(And(*self.sentences), *assumptions)
        return satisfiable(test) != False

# ===============================
#             Maze
# ===============================
class Maze:
    def __init__(self, filename):
        self.grid = []
        with open(filename, 'r') as f:
            for line in f:
                self.grid.append([int(x) for x in line.strip()])
        self.rows = len(self.grid)
        self.cols = len(self.grid[0]) if self.rows > 0 else 0

# ===============================
#        Initialization
# ===============================
pygame.init()
CELL_SIZE = 40
maze = Maze("maze.txt")
rows, cols = maze.rows, maze.cols
width, height = cols * CELL_SIZE, rows * CELL_SIZE
screen = pygame.display.set_mode((width * 2, height))
pygame.display.set_caption("Maze Localization")
clock = pygame.time.Clock()

free = [(r, c) for r in range(rows) for c in range(cols) if maze.grid[r][c] == 0]
belief = set(free)
true_pos = random.choice(free)
pos = true_pos

kb = KnowledgeBase()
actions = []
history = []

# ===============================
#            Drawing
# ===============================
def draw():
    screen.fill((255, 255, 255))
    for r in range(rows):
        for c in range(cols):
            color = (0, 0, 0) if maze.grid[r][c] == 1 else (220, 220, 220)
            pygame.draw.rect(screen, color, (c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE))
    for (r, c) in belief:
        pygame.draw.rect(screen, (255, 255, 0), (c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE))
    x_offset = width
    font = pygame.font.SysFont(None, 24)
    for i, (act, perc) in enumerate(history[-15:]):
        text = f"{i+1}: {act} -> {perc}"
        img = font.render(text, True, (0, 0, 0))
        screen.blit(img, (x_offset + 10, 10 + i * 30))
    pygame.display.flip()

# ===============================
#         Main Game Loop
# ===============================
steps = 0
running = True
while running and steps < 10 and len(belief) > 1:
    draw()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            r, c = pos
            moved = False
            action = None
            if event.key == pygame.K_UP and r > 0 and maze.grid[r - 1][c] == 0:
                pos = (r - 1, c); action = 'UP'; moved = True
            elif event.key == pygame.K_DOWN and r < rows - 1 and maze.grid[r + 1][c] == 0:
                pos = (r + 1, c); action = 'DOWN'; moved = True
            elif event.key == pygame.K_LEFT and c > 0 and maze.grid[r][c - 1] == 0:
                pos = (r, c - 1); action = 'LEFT'; moved = True
            elif event.key == pygame.K_RIGHT and c < cols - 1 and maze.grid[r][c + 1] == 0:
                pos = (r, c + 1); action = 'RIGHT'; moved = True
            if moved:
                p = (
                    1 if pos[0] == 0 or maze.grid[pos[0] - 1][pos[1]] == 1 else 0,
                    1 if pos[0] == rows - 1 or maze.grid[pos[0] + 1][pos[1]] == 1 else 0,
                    1 if pos[1] == cols - 1 or maze.grid[pos[0]][pos[1] + 1] == 1 else 0,
                    1 if pos[1] == 0 or maze.grid[pos[0]][pos[1] - 1] == 1 else 0
                )
                kb.add_percept(pos[0], pos[1], p)
                actions.append(action)
                history.append((action, p))
                new_belief = set()
                for start in free:
                    if kb.entails(maze, start, actions):
                        new_belief.add(start)
                belief = new_belief
                steps += 1

# ===============================
#        Final Display
# ===============================
draw()
pygame.time.wait(3000)
print(f"True position: {true_pos}")
print(f"Estimated belief: {belief}")
pygame.quit()
sys.exit()
