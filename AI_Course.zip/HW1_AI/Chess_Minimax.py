import math
import time
import pygame as p
import chess

WIDTH = HEIGHT = 512
MOVE_LOG_PANEL_WIDTH = 290
MOVE_LOG_PANEL_HEIGHT = HEIGHT
DIMENSION = 8
SQ_SIZE = HEIGHT // DIMENSION
MAX_FPS = 240
IMAGES = {}

ai_analysis_result = []
USE_POSITIONAL_EVAL = True


def load_images():
    pieces = ["wp", "wn", "wb", "wr", "wq", "wk", "bp", "bn", "bb", "br", "bq", "bk"]
    for piece in pieces:
        IMAGES[piece] = p.transform.scale(p.image.load("images/" + piece + ".png"), (SQ_SIZE, SQ_SIZE))


def main():
    p.init()
    screen = p.display.set_mode((WIDTH + MOVE_LOG_PANEL_WIDTH, HEIGHT))
    clock = p.time.Clock()
    screen.fill(p.Color("white"))
    board = chess.Board()
    load_images()
    sqSelected = None
    playerClicks = []
    gameOver = False
    playerOne = True
    playerTwo = False

    global ai_analysis_result

    running = True
    while running:
        humanTurn = (board.turn == chess.WHITE and playerOne) or (board.turn == chess.BLACK and playerTwo)
        for e in p.event.get():
            if e.type == p.QUIT:
                running = False
            elif e.type == p.MOUSEBUTTONDOWN:
                if not gameOver and humanTurn:
                    location = p.mouse.get_pos()
                    col = location[0] // SQ_SIZE
                    row = location[1] // SQ_SIZE
                    if col >= 8:
                        continue
                    square = chess.square(col, 7 - row)
                    if sqSelected == square:
                        sqSelected = None
                        playerClicks = []
                    else:
                        playerClicks.append(square)
                        if len(playerClicks) == 2:
                            move = chess.Move(playerClicks[0], playerClicks[1])
                            if move in board.legal_moves:
                                board.push(move)
                                playerClicks = []
                                sqSelected = None
                            else:
                                playerClicks = [square]
                                sqSelected = square
            elif e.type == p.KEYDOWN:
                if e.key == p.K_z:
                    if board.move_stack:
                        board.pop()
                        gameOver = False
                elif e.key == p.K_r:
                    board = chess.Board()
                    gameOver = False
                    sqSelected = None
                    playerClicks = []

        if not gameOver and not humanTurn:
            ai_analysis_result = analyze_ai_behavior(board, [1, 2, 3])
            # Use the deepest search's move (last element) as the AI's move
            ai_move = ai_analysis_result[-1][1] if ai_analysis_result else None
            if ai_move:
                board.push(ai_move)

        drawGameState(screen, board, sqSelected if humanTurn else None)

        if board.is_checkmate():
            gameOver = True
            # Determine winner: if board.turn is checkmated, the opposite wins
            winner = "White" if board.turn == chess.BLACK else "Black"
            drawEndGameText(screen, f"Checkmate! {winner} wins!")
        elif board.is_stalemate() or board.is_insufficient_material():
            gameOver = True
            drawEndGameText(screen, "Draw!")

        clock.tick(MAX_FPS)
        p.display.flip()


def analyze_ai_behavior(board, depths=[1, 2, 3]):
    analysis = []
    for depth in depths:
        start = time.time()
        move = get_best_move(board, depth)
        duration = time.time() - start
        if move:
            board.push(move)
            score = evaluate_board_positional(board) if USE_POSITIONAL_EVAL else evaluate_board(board)
            board.pop()
        else:
            score = 0
        analysis.append((depth, move, score, duration))
    return analysis


def get_best_move(board, depth):
    best_move = None
    # Save the player's color for which we are choosing a move.
    player_color = board.turn
    best_value = -math.inf if player_color == chess.WHITE else math.inf

    for move in board.legal_moves:
        board.push(move)
        # Use not player_color for the next level, since the turn switches.
        value = minimax(board, depth - 1, -math.inf, math.inf, board.turn == chess.WHITE)
        board.pop()
        if player_color == chess.WHITE and value > best_value:
            best_value = value
            best_move = move
        elif player_color == chess.BLACK and value < best_value:
            best_value = value
            best_move = move
    return best_move


def minimax(board, depth, alpha, beta, maximizing_player):
    if depth == 0 or board.is_game_over():
        return evaluate_board_positional(board) if USE_POSITIONAL_EVAL else evaluate_board(board)
    if maximizing_player:
        max_eval = -math.inf
        for move in board.legal_moves:
            board.push(move)
            eval = minimax(board, depth - 1, alpha, beta, False)
            board.pop()
            max_eval = max(max_eval, eval)
            alpha = max(alpha, eval)
            if beta <= alpha:
                break
        return max_eval
    else:
        min_eval = math.inf
        for move in board.legal_moves:
            board.push(move)
            eval = minimax(board, depth - 1, alpha, beta, True)
            board.pop()
            min_eval = min(min_eval, eval)
            beta = min(beta, eval)
            if beta <= alpha:
                break
        return min_eval


def evaluate_board(board):
    if board.is_checkmate():
        return -1000 if board.turn == chess.WHITE else 1000
    elif board.is_stalemate() or board.is_insufficient_material():
        return 0

    piece_values = {
        chess.PAWN: 1,
        chess.KNIGHT: 3,
        chess.BISHOP: 3,
        chess.ROOK: 5,
        chess.QUEEN: 9,
        chess.KING: 0
    }

    value = 0
    for square, piece in board.piece_map().items():
        piece_value = piece_values[piece.piece_type]
        value += piece_value if piece.color == chess.WHITE else -piece_value
    return value


def evaluate_board_positional(board):
    value = evaluate_board(board)
    center_squares = [chess.D4, chess.E4, chess.D5, chess.E5]
    for sq in center_squares:
        piece = board.piece_at(sq)
        if piece:
            value += 0.5 if piece.color == chess.WHITE else -0.5
    return value


def drawGameState(screen, board, sqSelected):
    drawBoard(screen)
    highlightSelected(screen, sqSelected)
    drawPieces(screen, board)
    drawMoveLog(screen, board)


def drawBoard(screen):
    colors = [p.Color("white"), p.Color("gray")]
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            color = colors[(r + c) % 2]
            p.draw.rect(screen, color, p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))


def highlightSelected(screen, sqSelected):
    if sqSelected:
        col, row = chess.square_file(sqSelected), 7 - chess.square_rank(sqSelected)
        s = p.Surface((SQ_SIZE, SQ_SIZE))
        s.set_alpha(100)
        s.fill(p.Color("blue"))
        screen.blit(s, (col * SQ_SIZE, row * SQ_SIZE))


def drawPieces(screen, board):
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            square = chess.square(c, 7 - r)
            piece = board.piece_at(square)
            if piece:
                piece_type = piece.symbol().lower()
                piece_color = 'w' if piece.color == chess.WHITE else 'b'
                screen.blit(IMAGES[piece_color + piece_type], p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))


def drawMoveLog(screen, board):
    moveLogRect = p.Rect(WIDTH, 0, MOVE_LOG_PANEL_WIDTH, MOVE_LOG_PANEL_HEIGHT)
    p.draw.rect(screen, p.Color("black"), moveLogRect)
    moveLog = board.move_stack
    moveTexts = []
    for i in range(0, len(moveLog), 2):
        moveString = str(i // 2 + 1) + ". " + str(moveLog[i])
        if i + 1 < len(moveLog):
            moveString += " " + str(moveLog[i + 1])
        moveTexts.append(moveString)
    font = p.font.SysFont("Arial", 14, False, False)
    textY = 5
    for text in moveTexts:
        textObject = font.render(text, True, p.Color("white"))
        screen.blit(textObject, (WIDTH + 5, textY))
        textY += 20

    global ai_analysis_result
    if ai_analysis_result:
        font2 = p.font.SysFont("Arial", 14, True, False)
        screen.blit(font2.render("AI Analysis:", True, p.Color("white")), (WIDTH + 5, textY))
        textY += 20
        for depth, move, score, duration in ai_analysis_result:
            info = f"depth {depth}: {move}, score: {score}, time: {round(duration, 2)}s"
            screen.blit(font.render(info, True, p.Color("lightgray")), (WIDTH + 5, textY))
            textY += 18


def drawEndGameText(screen, text):
    font = p.font.SysFont("Arial", 32, True, False)
    textObject = font.render(text, False, p.Color("red"))
    textLocation = p.Rect(0, 0, WIDTH, HEIGHT).move(
        WIDTH / 2 - textObject.get_width() / 2,
        HEIGHT / 2 - textObject.get_height() / 2
    )
    screen.blit(textObject, textLocation)


if __name__ == "__main__":
    main()
