import numpy as np
import pandas as pd
import gym
from gym import spaces
import matplotlib.pyplot as plt
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

# 1. Generating sample data
def generate_sample_data(days=1000):
    np.random.seed(42)
    dates = pd.date_range(start="2020-01-01", periods=days, freq='B')
    prices = np.cumprod(1 + np.random.normal(0, 0.01, days)) * 100
    volume = np.random.randint(1e6, 5e6, size=days)
    df = pd.DataFrame({'Date': dates, 'Adj Close': prices, 'Volume': volume})
    df.to_csv("sample_data.csv", index=False)
    return "sample_data.csv"

# 2. Preprocess data and generate processed_data.csv
def preprocess_data(input_csv, output_csv='processed_data.csv'):
    data = pd.read_csv(input_csv, parse_dates=['Date'])
    
    # Discretize Adj Close
    adj_close_bins = pd.qcut(data['Adj Close'], q=3, labels=['Low', 'Medium', 'High'])
    data['Adj_Close_Bin'] = adj_close_bins.map({'Low': 0, 'Medium': 1, 'High': 2})
    
    # Discretize Volume
    volume_bins = pd.qcut(data['Volume'], q=3, labels=['Low', 'Medium', 'High'])
    data['Volume_Bin'] = volume_bins.map({'Low': 0, 'Medium': 1, 'High': 2})
    
    # Calculate and discretize Daily Returns
    data['Daily_Return'] = data['Adj Close'].pct_change().fillna(0)
    data['Daily_Return_Bin'] = pd.cut(data['Daily_Return'],
                                      bins=[-np.inf, -0.002, 0.002, np.inf],
                                      labels=['Down', 'Flat', 'Up'],
                                      include_lowest=True)
    data['Daily_Return_Bin'] = data['Daily_Return_Bin'].map({'Down': 0, 'Flat': 1, 'Up': 2}).fillna(1)
    
    # Calculate and discretize RSI
    def calculate_rsi(data, periods=14):
        delta = data['Adj Close'].diff().fillna(0)
        gain = delta.clip(lower=0)
        loss = -delta.clip(upper=0)
        avg_gain = gain.rolling(window=periods).mean()
        avg_loss = loss.rolling(window=periods).mean()
        rs = avg_gain / (avg_loss + 1e-8)
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    data['RSI'] = calculate_rsi(data)
    data['RSI_Bin'] = pd.cut(data['RSI'],
                             bins=[-np.inf, 30, 70, np.inf],
                             labels=['Oversold', 'Neutral', 'Overbought'],
                             include_lowest=True)
    data['RSI_Bin'] = data['RSI_Bin'].map({'Oversold': 0, 'Neutral': 1, 'Overbought': 2}).fillna(1)
    
    # Save preprocessed data
    output_data = data[['Date', 'Adj Close', 'Adj_Close_Bin', 'Volume_Bin', 'Daily_Return', 'Daily_Return_Bin', 'RSI_Bin']]
    output_data.to_csv(output_csv, index=False)
    return output_csv

# 3. Modified load_and_preprocess function
def load_and_preprocess(csv_path):
    df = pd.read_csv(csv_path, parse_dates=['Date'], index_col='Date')
    df['Adj_Close_Bin'] = df['Adj_Close_Bin'].astype(int)
    df['Volume_Bin'] = df['Volume_Bin'].astype(int)
    df['Daily_Return_Bin'] = df['Daily_Return_Bin'].astype(int)
    df['RSI_Bin'] = df['RSI_Bin'].astype(int)
    return df

# 4. Trading environment design
class TradingEnv(gym.Env):
    def __init__(self, data, cost=0.001):
        super(TradingEnv, self).__init__()
        self.data = data.reset_index()
        self.n = len(data)
        if data['Daily_Return_Bin'].nunique() == 0 or data['RSI_Bin'].nunique() == 0 or \
           data['Adj_Close_Bin'].nunique() == 0 or data['Volume_Bin'].nunique() == 0:
            raise ValueError("Data contains invalid or missing bins.")
        self.observation_space = spaces.MultiDiscrete([
            data['Daily_Return_Bin'].nunique(),
            data['RSI_Bin'].nunique(),
            data['Adj_Close_Bin'].nunique(),
            data['Volume_Bin'].nunique()
        ])
        self.action_space = spaces.Discrete(3)  # 0=Short, 1=Hold, 2=Long
        self.cost = cost
        self.reset()

    def reset(self):
        self.idx = 0
        self.nav = 1.0
        self.position = 0
        return self._get_state()

    def _get_state(self):
        row = self.data.loc[self.idx]
        return np.array([row['Daily_Return_Bin'], row['RSI_Bin'], row['Adj_Close_Bin'], row['Volume_Bin']], dtype=int)

    def step(self, action):
        ret = self.data.loc[self.idx, 'Daily_Return']
        reward = self.position * ret - self.cost * abs(action - 1)
        self.position = action - 1  # map 0→-1, 1→0, 2→1
        self.idx += 1
        done = self.idx >= self.n - 1 or self.nav <= 0
        self.nav *= (1 + self.position * ret)
        next_state = self._get_state()
        return next_state, reward, done, {}

# 5. Q-Learning agent
class QLearningAgent:
    def __init__(self, env, alpha=0.1, gamma=0.99, epsilon=1.0, eps_decay=0.995, eps_min=0.01):
        self.env = env
        self.alpha = alpha
        self.gamma = gamma
        self.epsilon = epsilon
        self.eps_decay = eps_decay
        self.eps_min = eps_min
        obs_space = env.observation_space.nvec
        self.Q = np.zeros((*obs_space, env.action_space.n))

    def choose_action(self, state):
        if np.random.rand() < self.epsilon:
            return self.env.action_space.sample()
        return np.argmax(self.Q[tuple(state)])

    def learn(self, state, action, reward, next_state, done):
        q_predict = self.Q[tuple(state)][action]
        if done:
            q_target = reward
        else:
            q_target = reward + self.gamma * np.max(self.Q[tuple(next_state)])
        self.Q[tuple(state)][action] += self.alpha * (q_target - q_predict)
        self.epsilon = max(self.epsilon * self.eps_decay, self.eps_min)

# 6. Training loop
def train(agent, episodes=1000):
    history = []
    for ep in range(episodes):
        state = agent.env.reset()
        done = False
        total_reward = 0
        while not done:
            action = agent.choose_action(state)
            next_state, reward, done, _ = agent.env.step(action)
            agent.learn(state, action, reward, next_state, done)
            state = next_state
            total_reward += reward
        history.append((ep, total_reward, agent.env.nav))
    return history

# 7. Evaluation
def evaluate(agent):
    state = agent.env.reset()
    done = False
    navs = [agent.env.nav]
    actions = []
    while not done:
        action = np.argmax(agent.Q[tuple(state)])
        actions.append(action)
        state, _, done, _ = agent.env.step(action)
        navs.append(agent.env.nav)
    return actions, navs

# 8. Plotting results
def plot_nav(history, buy_and_hold_nav):
    eps, rewards, navs = zip(*history)
    plt.figure()
    plt.plot(eps, navs, label='Q-Learning NAV')
    plt.axhline(buy_and_hold_nav, linestyle='--', label='Buy & Hold')
    plt.xlabel('Episode')
    plt.ylabel('NAV')
    plt.legend()
    plt.show()

# 9. Performance metrics
def performance_metrics(navs):
    returns = np.diff(navs) / navs[:-1]
    total_return = navs[-1] - 1
    sharpe = returns.mean() / (returns.std() + 1e-8) * np.sqrt(252)
    drawdowns = 1 - np.array(navs) / np.maximum.accumulate(navs)
    max_drawdown = np.max(drawdowns)
    wins = np.sum(returns > 0)
    losses = np.sum(returns < 0)
    win_loss_ratio = wins / (losses + 1e-8)
    return total_return, sharpe, max_drawdown, win_loss_ratio

# Example usage
if __name__ == "__main__":
    csv_filename = generate_sample_data(days=1000)
    preprocess_data(csv_filename)
    
    df = load_and_preprocess('processed_data.csv')
    train_size = int(len(df) * 0.7)
    train_df = df.iloc[:train_size]
    test_df = df.iloc[train_size:]

    env = TradingEnv(train_df)
    agent = QLearningAgent(env)
    history = train(agent)

    test_env = TradingEnv(test_df)
    agent.env = test_env
    actions, navs = evaluate(agent)

    buy_and_hold_nav = test_df['Adj Close'].iloc[-1] / test_df['Adj Close'].iloc[0]
    plot_nav(history, buy_and_hold_nav)

    total_return, sharpe, max_dd, wl_ratio = performance_metrics(navs)
    print(f"Total Return: {total_return:.4f}")
    print(f"Sharpe Ratio: {sharpe:.4f}")
    print(f"Max Drawdown: {max_dd:.4f}")
    print(f"Win/Loss Ratio: {wl_ratio:.2f}")